from django.apps import AppConfig


class GenderwatchConfig(AppConfig):
    name = 'genderwatch'
